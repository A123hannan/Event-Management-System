#include <iostream>
#include<Windows.h>
#include<string>
#include<fstream>
#include<conio.h>
#include<cstdlib>
#include<sstream>
#include <vector>
#include <limits>
#include <iomanip>
using namespace std;

void MainMenu();
void Login();
void SignUP();
void inside_Login(string customerName, string customerEmail);
void saveEventID(int eventID) {
    ofstream outFile("eventID.txt");
    if (outFile.is_open()) {
        outFile<<eventID;
        outFile.close();
        //cout << "Event ID saved successfully!" << endl;
    } else {
        cout << "Error opening file to save event ID!" << endl;
    }
}
int readEventID() {
    int eventID = -1; 
    ifstream inFile("eventID.txt");
    if (inFile.is_open()) {
        inFile>>eventID; 
        inFile.close();
        return eventID;
    } else {
        //cout << "Error opening file to read event ID!" << endl;
        return eventID;
    }
    
}
int readEventIDplus1() {
    int eventID = -1; 
    ifstream inFile("eventID.txt");
    if (inFile.is_open()) {
        inFile>>eventID; 
        inFile.close();
        return eventID+2;
    } else {
        //cout << "Error opening file to read event ID!" << endl;
        return eventID+2;
    }
    
}
class Person {
	private:
		string name;
		string phonenumber;
		string Email;
		string Password;
	public:
		Person():name(""),phonenumber(""),Email("")
		{
		}
		void setname(string name) {
			this->name=name;
		}
		string getname() {
			return name;
		}
		void setphone(string ph) {
			this->phonenumber=ph;
		}
		string getphone() {
			return phonenumber;
		}
		void setemail(string email) {
			this->Email=email;
		}
		string getemail() {
			return Email;
		}
		void setPassword(string pass){
			this->Password=pass;
		}
		string getPassword(){
			return Password;
		}


};
class Customer:public Person{
		private:
			Customer* Next;
			Customer* Prev;
		public:
			
			void setnext(Customer* next) {
				this->Next=next;
			}
			void setprevious(Customer* pre) {
				this->Prev=pre;
			}
			string getCustomername() {
				return Person::getname();
			}
			string getCustomrphone() {
			    return Person::getphone();
			}
			string getCustomeremail() {
				return Person::getemail();
			}
			string getCustomerpassword(){
				return Person::getPassword();
			}
			Customer* getCustomernext() {
				return Next;
			}
			Customer* getCustomerpre() {
				return Prev;
			}
			void setnameCustomer(string name) {
				if (!name.empty()) {
					Person::setname(name);
				}
				else {
					cout<<"Name can't be empty"<<endl;
				}
			}
			void setphoneCustomer(string phone) {
				if (!phone.empty()) {
					Person::setphone(phone);
				}
				else {
					cout << "Phone # can't be empty" << endl;
				}
			}
			void setemailCustomer(string email) {
				if (!email.empty()) {
					Person::setemail(email);
				}
				else {
					cout << "Email can't be empty" << endl;
				}
			}
			void setpasswordCustomer(string pass) {
				if (!pass.empty()) {
					Person::setPassword(pass);
				}
				else {
					cout << "Password can't be empty" << endl;
				}
			}
			void saveToFile() {
			    ofstream file("customers.txt", ios::app);
			    if (file.is_open()) {
			        file << getCustomername() << "," << getCustomrphone() << "," << getCustomeremail() << "," << getCustomerpassword() << endl;
			        file.close();
			    } else {
			        cout << "Unable to open file!" << endl;
			    }
			}
	    void showevents(){
	    	
		}

};
class CustomerList{
	private:
		Customer* head;
		Customer* tail;
		public:
			CustomerList():head(NULL),tail(NULL){
			}
		void insertCustomer(string name,string Phoneno,string email,string Pass){
	
			Customer* newcustomer=new Customer();
			newcustomer->setnameCustomer(name);
			newcustomer->setphoneCustomer(Phoneno);
			newcustomer->setemailCustomer(email);
			newcustomer->setpasswordCustomer(Pass);
			   newcustomer->saveToFile();
		if(head==NULL){
		  newcustomer->setnext(NULL);
		  newcustomer->setprevious(NULL);
		  head=newcustomer;
		  tail=newcustomer;
		}
		else{
			Customer* temp=head;
			while(temp->getCustomernext()!=NULL){
				temp=temp->getCustomernext();
			}
			newcustomer->setprevious(temp);
			temp->setnext(newcustomer);
			tail=newcustomer;
			
		    }
		}
		
		void deleteCustomer(string email,string password){
			Customer* temp=head;
			if(head==NULL){
				cout<<"No Data found for Email: "<<email<<"\n And Password:   "<<password<<endl;
			}
			else{
				Customer* pre;
				while(temp!=NULL&&(temp->getemail()!=email && temp->getPassword()!=password)){
					pre =temp;
					temp=temp->getCustomernext();
				}
				pre->setnext(temp->getCustomernext());
				temp->getCustomernext()->setprevious(pre);
				delete temp;				
			}
		}
				    // Function to verify login details
		bool verifyLogin(string email, string password, string& name) {
		    ifstream file("customers.txt");
		    string line;
		    while (getline(file, line)) {
		        
		        size_t pos1 = line.find(",");
		        size_t pos2 = line.find(",", pos1 + 1);
		        size_t pos3 = line.find(",", pos2 + 1);
		        
		        
		        string fileName = line.substr(0, pos1); 
		        string fileEmail = line.substr(pos2 + 1, pos3 - pos2 - 1); 
		        string filePassword = line.substr(pos3 + 1); // Get password
		        
		        if (fileEmail == email && filePassword == password) {
		            name = fileName; // Store the name
		            return true;     
		        }
		    }
		    return false; 
		}

		void displayBookings(string customerName,string customerEmail) {
		    ifstream bookingFile("Booking.txt");
		    string line;
		    bool found = false;
		
		    cout << "Your Bookings:" << endl;
		    cout << "------------------------------------------------" << endl;
		
		    while (getline(bookingFile, line)) {
		        size_t pos1 = line.find(",");
		        size_t pos2 = line.find(",", pos1 + 1);
		        size_t pos3 = line.find(",", pos2 + 1);
		        size_t pos4 = line.find(",", pos3 + 1);
		        size_t pos5 = line.find(",", pos4 + 1);
		
		        string email = line.substr(pos1 + 1, pos2 - pos1 - 1); // Extract email
		        if (email == customerEmail) {
		            string name = line.substr(0, pos1);
		            string eventID = line.substr(pos2 + 1, pos3 - pos2 - 1);
		            string eventType = line.substr(pos3 + 1, pos4 - pos3 - 1);
		            string ticketType = line.substr(pos4 + 1, pos5 - pos4 - 1);
		            string ticketCount = line.substr(pos5 + 1);
		
		            cout << "Name: " << name << endl;
		            cout << "Event ID: " << eventID << endl;
		            cout << "Event Type: " << eventType << endl;
		            cout << "Ticket Type: " << ticketType << endl;
		            cout << "Tickets Purchased: " << ticketCount << endl;
		            cout << "------------------------------------------------" << endl;
		            found = true;
		        }
		    }
		
		    if (!found) {
		        cout << "No bookings found!" << endl;
		    }
		
		    bookingFile.close();
		    cout<<"Press Enter to Go Back...."<<endl;
		    getch();
		    system("cls");
		    inside_Login(customerName,customerEmail);
		
		}


		void displaycustomers(){
			Customer* temp=head;
			int i=1;
			cout<<"ALL CUSTOMERS AND THEIR DETAILS ARE :"<<endl<<endl;
			while(temp!=NULL){
				cout<<"________________________________________________________" << endl;
    	    	cout<<"| Name    : " << temp->getCustomername()<<"            "<<endl;
        		cout<<"| Phone   : " << temp->getCustomrphone()<<"            "<<endl;
				cout<<"| Email   : " << temp->getCustomeremail()<<"           "<<endl;
				cout<<"| Password: " << temp->getCustomerpassword() << "      " << endl;
				cout<<"|______________________________________________________" << endl;
				cout<<"                                |    "<<endl;
				cout<<"                                |    "<<endl;
				cout<<"                               \\|/   "<<endl;
				temp=temp->getCustomernext();
			}
		}
	
};
class Organizer:public Person {

	public:
		void setnameOrganizer(string name) {
			if (!name.empty()) {
				Person::setname(name);
			}
			else {
				cout << "Name can't be empty" << endl;
			}
		}
		void setphoneOrganizer(string phone) {
			if (!phone.empty()) {
				Person::setphone(phone);
			}
			else {
				cout << "Phone # can't be empty" << endl;
			}
		}
		void setemailOrganizer(string email) {
			if (!email.empty()) {
				Person::setemail(email);
			}
			else {
				cout << "Email can't be empty" << endl;
			}
		}
		void setpasswordOrganizer(string pass) {
			if (!pass.empty()) {
				Person::setPassword(pass);
			}
			else {
				cout << "Password can't be empty" << endl;
			}
		}
		string getOrganizationname() {
			return Person::getname();
		}
		string getOrganizationphone() {
			return Person::getphone();
		}
		string getOrganizationemail() {
			return Person::getemail();
		}
		string getOrganizationpassword(){
			return Person::getPassword();
		}

};
class Tickets {
private:
    static int ticketID;
    int currentID;
    string ticketname;
    string ticketbuyername;
    string platinumprice;
    string goldprice;
    string silverprice;
    string date;

    Tickets* next;

public:
    Tickets() : ticketname(""), ticketbuyername(""), platinumprice(""), goldprice(""), silverprice(""), date(""), next(NULL) {
        ticketID++;
        currentID = ticketID;
    }
    int getTicketID() const { 
	return currentID; 
	}
    void setTicketname(const string& name) { 
	this->ticketname = name; 
	}
    string getticketname() const { 
	return ticketname; 
	}
    void setTicketbuyername(const string& name) { 
	this->ticketbuyername = name; 
	}
    string getticketbuyername() const { 
	return ticketbuyername; 
	}
    void setplatinumprice(const string& price) { 
	this->platinumprice = price; 
	}
    string getplatinumprice() const { 
	return platinumprice; 
	}
    void setgoldprice(const string& price) { 
	this->goldprice = price; 
	}
    string getgoldprice() const { 
	return goldprice; 
	}
    void setsilverprice(const string& price) { 
	this->silverprice = price; 
	}
    string getsilverprice() const { 
	return silverprice; 
	}
    void setdate(const string& date) { 
	this->date = date; 
	}
    string getdate() const { 
	return date; 
	}
    void setticketsnext(Tickets* next) { 
	this->next = next; 
	}
    Tickets* getticketsnext() const { 
	return next; 
	}
};
int Tickets::ticketID = 0;
class Ticketsqueue {
protected:
    Tickets* front = NULL;
    Tickets* rear = NULL;

public:
	    virtual ~Ticketsqueue() {
	        while (front) {
	            dequeue();
	        }
	    }
	
	    bool isempty() const { return front == NULL; }
	
	    virtual void enqueue(const string& ticketname, const string& price) = 0;
	    void dequeue() {
	        if (isempty()) return;
	        Tickets* temp = front;
	        front = front->getticketsnext();
	        delete temp;
	        if (front == NULL) rear = NULL;
	    }
	
	    Tickets* getfront() const { return front; }
	
	    bool purchaseTicket() {
	        if (isempty()) {
	            cout << "No tickets left." << endl;
	            return false;
	        }
	        dequeue();
	        return true;
	    }
	
	    int ticketsLeft() const {
	        int count = 0;
	        Tickets* temp = front;
	        while (temp != NULL) {
	            count++;
	            temp = temp->getticketsnext();
	        }
	        return count;
	    }
	
	    virtual string getPrice(const Tickets* ticket) const = 0;
};
class Ticketsqueue_plt : public Ticketsqueue {
public:
	    void enqueue(const string& ticketname, const string& price) override {
	        Tickets* newticket = new Tickets();
	        newticket->setTicketname(ticketname);
	        newticket->setplatinumprice(price);
	        if (isempty()) front = rear = newticket;
	        else rear->setticketsnext(newticket); rear = newticket;
	    }
	    string getPrice(const Tickets* ticket) const override { return ticket->getplatinumprice(); }
};
class Ticketsqueue_gld : public Ticketsqueue {
public:
	    void enqueue(const string& ticketname, const string& price) override {
	        Tickets* newticket = new Tickets();
	        newticket->setTicketname(ticketname);
	        newticket->setgoldprice(price);
	        if (isempty()) front = rear = newticket;
	        else rear->setticketsnext(newticket); rear = newticket;
	    }
	    string getPrice(const Tickets* ticket) const override { return ticket->getgoldprice(); }
};
class Ticketsqueue_slv : public Ticketsqueue {
public:
	    void enqueue(const string& ticketname, const string& price) override {
	        Tickets* newticket = new Tickets();
	        newticket->setTicketname(ticketname);
	        newticket->setsilverprice(price);
	        if (isempty()) front = rear = newticket;
	        else rear->setticketsnext(newticket); rear = newticket;
	    }
	    string getPrice(const Tickets* ticket) const override { return ticket->getsilverprice(); }
};
class Event:public Organizer{
	private:
		//static int idCounter; // Static counter for unique event IDs
    	int eventID;
		string event_type;
		//string tickets_type;      //premium,business,economy
		//int ticket_price;
		string platinumprice;
		string goldprice;
		string silverprice;
		string date;
		Event* Next;
		Event* Prev;
		
	public:
    Ticketsqueue_plt platinumTickets;
    Ticketsqueue_gld goldTickets;
    Ticketsqueue_slv silverTickets;
    Event() : eventID(), Next(NULL), Prev(NULL) {}
    
			
    	void setnext(Event* next) {
			this->Next = next;
		}
		void setprevious(Event* pre) {
			this->Prev = pre;
		}
		Event* getnext() {
			return Next;
		}
		Event* getpre() {
			return Prev;
		}
		
		void seteventype(string evtyp){
			this->event_type=evtyp;
		}
		string geteventype(){
			return event_type;
		}
		void seteventID(int id){
			this->eventID=id;
		}
		void seteventdate(string date){
			this->date=date;
		}
		string getEventdate(){
			return date;
		}
		void setnameEvent(string name) {
			if (!name.empty()) {
				Organizer::setnameOrganizer(name);
			}
			else {
				cout << "Name can't be empty" << endl;
			}
		}
		void setphoneEvent(string phone) {
			if (!phone.empty()) {
				Organizer::setphoneOrganizer(phone);
			}
			else {
				cout << "Phone # can't be empty" << endl;
			}
		}
		void setemailEvent(string email) {
			if (!email.empty()) {
				Organizer::setemailOrganizer(email);
			}
			else {
				cout << "Email can't be empty" << endl;
			}
		}
		void setpasswordEvent(string pass) {
			if (!pass.empty()) {
				Organizer::setpasswordOrganizer(pass);
			}
			else {
				cout << "Password can't be empty" << endl;
			}
		}
		string getEventname() {
			return Organizer::getOrganizationname();
		}
		string getEventphone() {
			return Organizer::getOrganizationphone();
		}
		string getEventemail() {
			return Organizer::getOrganizationemail();
		}
		string getEventpasssword(){
			return Organizer::getOrganizationpassword();
		}
		
		
	    void setplatinumprice(string price){
			this->platinumprice=price;
		}
		string getplatinumprice(){
			return platinumprice;
		}
		void setgoldprice(string price){
			this->goldprice=price;
		}
		string getgoldprice(){
			return goldprice;
		}
		void setsilverprice(string price){
			this->silverprice=price;
		}
		string getsilverprice(){
			return silverprice;
		}
		int getEventID(){
			return eventID;
		}
		void displayTicketCounts() const {
		    cout << "Available Tickets for Event ID " << eventID << ":" << endl;
		    cout << "Platinum: " << platinumTickets.ticketsLeft() << endl;
		    cout << "Gold: " << goldTickets.ticketsLeft() << endl;
		    cout << "Silver: " << silverTickets.ticketsLeft() << endl;
		}	
		void saveToFile() {
	        ofstream file("EventsOrganizer.txt", ios::app);
	        if (file.is_open()) {
	            file << getOrganizationname() << "," << getOrganizationphone() << "," << getOrganizationemail() << "," << getOrganizationpassword() << endl;
	            file.close();
	        } else {
	            cout << "Unable to open file!" << endl;
	        }}
	    void saveToFileEvent() {
	        ofstream file("Events.txt", ios::app);
	        if (file.is_open()) {
	            file << eventID << "," << getOrganizationname() << "," << geteventype() << "," << getEventdate() << ","
	                 << getplatinumprice() << "," << getgoldprice() << "," << getsilverprice() << endl;
	            file.close();
	        } else {
	            cout << "Unable to open file!" << endl;
	        }
	    }
	   void saveQueuesToFile() {
	        saveQueueToFile("Queues.txt", platinumTickets, eventID, "platinum");
	        saveQueueToFile("Queues.txt", goldTickets, eventID, "gold");
	        saveQueueToFile("Queues.txt", silverTickets, eventID, "silver");
	    }
	
	    void loadQueuesFromFile() {
	        loadQueueFromFile("Queues.txt", platinumTickets, eventID, "platinum");
	        loadQueueFromFile("Queues.txt", goldTickets, eventID, "gold");
	        loadQueueFromFile("Queues.txt", silverTickets, eventID, "silver");
	    }
	    void addTickets(int numPlatinumToAdd, int numGoldToAdd, int numSilverToAdd) {
	        string eventname = geteventype();
	        string platinumPrice = getplatinumprice();
	        string goldPrice = getgoldprice();
	        string silverPrice = getsilverprice();
	
	        for (int i = 0; i < numPlatinumToAdd; i++) {
	            platinumTickets.enqueue(eventname, platinumPrice);
	        }
	        cout << "Platinum tickets added successfully!" << endl;
	
	        for (int i = 0; i < numGoldToAdd; i++) {
	            goldTickets.enqueue(eventname, goldPrice);
	        }
	        cout << "Gold tickets added successfully!" << endl;
	
	        for (int i = 0; i < numSilverToAdd; i++) {
	            silverTickets.enqueue(eventname, silverPrice);
	        }
	        cout << "Silver tickets added successfully!" << endl;
	
	         saveQueuesToFile(); 
	        cout<<"Press Enter to continue...."<<endl;
	        getch();
	    }
		
	private:
		void saveQueueToFile(const char* originalFilename, Ticketsqueue& queue, int eventID, const char* ticketType) {
	        const char* tempFilename = "Queues_temp.txt"; // Temporary file name
	
	        // Open the temporary file for writing (overwrite mode)
	        ofstream tempFile(tempFilename);
	
	        if (!tempFile.is_open()) {
	            cerr << "Error opening " << tempFilename << " for writing!" << endl;
	            return;
	        }
	
	        // Load the original file content first
	        ifstream originalFile(originalFilename);
	        if (originalFile.is_open()){
	            string line;
	            while(getline(originalFile,line)){
	                stringstream ss(line);
	                int fileEventID, fileTicketID;
	                string fileTicketType, fileTicketName, fileTicketPrice;
	                char comma;
	
	                if (ss >> fileEventID >> comma && getline(ss, fileTicketType, ',') &&
	                    ss >> fileTicketID >> comma && getline(ss, fileTicketName, ',') && getline(ss, fileTicketPrice, ',')) {
	                    if (fileEventID != eventID || fileTicketType != ticketType) {
	                        tempFile<<line<<endl;
	                    }
	                }
	            }
	            originalFile.close();
	        }
	
	        Tickets* temp = queue.getfront();
	        while (temp != NULL) {
	            tempFile << eventID << "," << ticketType << "," << temp->getTicketID() << ","
	                     << temp->getticketname() << "," << queue.getPrice(temp) << endl;
	            temp = temp->getticketsnext();
	        }
	        tempFile.close();
	
	        // Replace the original file with the temporary file
	        if (remove(originalFilename) != 0) {
	            cerr << "Error removing original file!" << endl;
	        }
	        if (rename(tempFilename, originalFilename) != 0) {
	            cerr << "Error renaming temporary file!" << endl;
	        }
	    }
	    void loadQueueFromFile(const char* filename, Ticketsqueue& queue, int eventID, const char* ticketType) {
	        ifstream file(filename);
	        if (file.is_open()) {
	            string line;
	            while (getline(file, line)) {
	                stringstream ss(line);
	                int fileEventID, fileTicketID;
	                string fileTicketType, fileTicketName, fileTicketPrice;
	                char comma;
	
	                if (ss >> fileEventID >> comma && getline(ss, fileTicketType, ',') &&
	                    ss >> fileTicketID >> comma && getline(ss, fileTicketName, ',') && getline(ss, fileTicketPrice, ',')) {
	                    if (fileEventID == eventID && fileTicketType == ticketType) {
	                        queue.enqueue(fileTicketName, fileTicketPrice);
	                    }
	                }
	            }
	            file.close();
	        }
	    }
};
//int Event::idCounter = 0;
void loadEventsFromFile();
void deleteList(Event*& head) {
    Event* current = head;

    while (current != NULL) {
        Event* temp = current; // Store the current node
        current = current->getnext(); // Move to the next node
        delete temp; // Delete the current node
    }

    head = NULL; 
}

class EventList{
	private:
		Event* head;
		Event* tail;
		bool isLoaded;
		
		void handleInvalidInput() {
	        std::cin.clear();
	        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	        std::cout << "Invalid input. Please enter a valid number." << std::endl;
	    }
		void removeQueuesFromFile(int eventID) {
		    ifstream inFile("Queues.txt");
		    ofstream outFile("Queues.tmp");
		
		    if (!inFile.is_open() || !outFile.is_open()) {
		        cerr << "Error opening queue files!" << endl;
		        return;
		    }
		
		    string line;
		    while (getline(inFile, line)) {
		        stringstream ss(line);
		        int fileEventID;
		        string fileTicketType;
		        char comma;
		
		        if (ss >> fileEventID >> comma && getline(ss, fileTicketType, ',')) {
		            if (fileEventID != eventID) {
		                outFile << line << endl;  // Write line back if eventID doesn't match
		            }
		        }
		    }
		
		    inFile.close();
		    outFile.close();
		
		    if (remove("Queues.txt") != 0) {
		        cerr << "Error removing original Queues.txt file!" << endl;
		    }
		    if (rename("Queues.tmp", "Queues.txt") != 0) {
		        cerr << "Error renaming temporary queue file!" << endl;
		    }
		}
	public:
		EventList():head(NULL),tail(NULL){
		}
		
		void insert_EventOrganizer_detail(string name,string phone,string email,string password){
			Event* newevent=new Event();
			newevent->setnameEvent(name);
			newevent->setphoneEvent(phone);
			newevent->setemailEvent(email);
			newevent->setpasswordEvent(password);
			newevent->saveToFile();
			if(head==NULL){
				newevent->setnext(NULL);
				newevent->setprevious(NULL);
				head=newevent;
				tail=newevent;
			}
			else{
				Event* temp=head;
				while(temp->getnext()!=NULL){
					temp=temp->getnext();
				}
				temp->setnext(newevent);
				newevent->setprevious(temp);
				tail=newevent;
			}
			//EventList newlist();
			system("cls");
			EventlistMenu(name);
			//char y;
			//cout<<"For Inserting Event : "<<endl;
			//Eventlist->insertinfo(string event_typ,string tckt_typ,int tckt_price,string date,newevent)
		}
		void insertEventList(int id,const string& orgname, const string& eventname, const string& pltprice, const string& gldprice, const string& slvprice, const string& date, int nooftickets_plt, int nooftickets_gld, int nooftickets_slv) {
	        Event* newEvent = new Event();
	        newEvent->seteventID(id);
	        newEvent->setnameOrganizer(orgname);
		    newEvent->seteventype(eventname);
		    newEvent->setplatinumprice(pltprice);
		    newEvent->setgoldprice(gldprice);
		    newEvent->setsilverprice(slvprice);
		    newEvent->seteventdate(date);
			for (int i = 0; i < nooftickets_plt; i++) {
		        newEvent->platinumTickets.enqueue(eventname, pltprice);
		        }
		    for (int i = 0; i < nooftickets_gld; i++) {
		        newEvent->goldTickets.enqueue(eventname, gldprice);
		        }
		        for (int i = 0; i < nooftickets_slv; i++) {
	            newEvent->silverTickets.enqueue(eventname, slvprice);
		        }
		
		        newEvent->saveToFileEvent(); // Save event details
		        newEvent->saveQueuesToFile(); // Save queues
		
		        if (head == NULL) {
		            head = newEvent;
		            tail = newEvent;
		        } else {
		            tail->setnext(newEvent);
		            newEvent->setprevious(tail);
		            tail = newEvent;
		        }
		    }


			void EventlistMenu(string orgname){
			string name=orgname;
			int choice;		
		    cout << "                                               <<<<<<<<<<<>>>>>>>>" << endl;
		   	cout << "                                          >>>>>>|Event Organizer|<<<<<<<<<" << endl;
		   	cout << "                                               <<<<<<<<<<<>>>>>>>>" << endl;
			//cout<<"<<<<<<<<<>>>>>>>>>"<<endl;
			//cout<<"                                            >>>>>>>>>|"<<orgname<< "|<<<<<<<<<"<<endl;
			//cout<<"<<<<<<<<<>>>>>>>>>"<<endl<<endl;
			cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl;
			cout<<"Choose your choice : "<<endl;
			cout<<"   <<<<<<<<<<>>>>>>>>     <<<<<<<<<<>>>>>>>>>      <<<<<<<<<<>>>>>>>>       <<<<<<<<<<>>>>>>>>      <<<<<<<<<<>>>>>>>>"<<endl;
			cout<<"1->| Insert   Event |  2->|  Update  Event  |   3->| Delete   Event |    4->|   Add Tickets  |   5->|       Exit     |"<<endl;
			cout<<"   <<<<<<<<<<>>>>>>>>     <<<<<<<<<<>>>>>>>>>      <<<<<<<<<<>>>>>>>>       <<<<<<<<<<>>>>>>>>      <<<<<<<<<<>>>>>>>>"<<endl;
  			while (true) {
		        cin >> choice;
		        // Check if input is Chracter
		        if (cin.fail()) {
		            cin.clear();
		            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore invalid input
		            std::cout << "Invalid input. Please choose correct choice: ";
		        } else {break;}
			}
			cin.ignore();
			if(choice==1){
            insertEvent(name);
            }
        else if (choice == 2) {
            system("cls");
            //loadEventsFromFile();
            updateEvent(name);
            system("cls");
            EventlistMenu(name);
        }
        else if (choice == 3) {
            system("cls");
            //loadEventsFromFile();
            deleteEvent(name);
            system("cls");
            EventlistMenu(name);
        }
         else if (choice == 4) {
            system("cls");
            //loadEventsFromFile();
            displayEventsFororganization(orgname); // Pass the organizer's name
            system("cls");
            EventlistMenu(name);
                    }
        else if (choice == 5) {
            system("cls");
            MainMenu(); // Assuming you have a MainMenu function
        }
        else{
        	system("cls");
        	EventlistMenu(name);
		}
			
			
		}
		//Function to verify login details
		bool verifyLoginEvent(string name, string email, string password) {
		    ifstream file("EventsOrganizer.txt");
		    if (!file.is_open()) {
		        cout << "Unable to open EventsOrganizer.txt!" << endl;
		        return false;
		    }
		
		    string line;
		    while (getline(file, line)) {
		        // Split the line based on commas to extract fields
		        size_t pos1 = line.find(",");
		        size_t pos2 = line.find(",", pos1 + 1);
		        size_t pos3 = line.find(",", pos2 + 1);
		
		        if (pos1 == string::npos || pos2 == string::npos || pos3 == string::npos) {
		            continue; // Skip lines that don't match the expected format
		        }
		
		        string fileName = line.substr(0, pos1);
		        string filePhone = line.substr(pos1 + 1, pos2 - pos1 - 1); // Phone is not used in login
		        string fileEmail = line.substr(pos2 + 1, pos3 - pos2 - 1);
		        string filePassword = line.substr(pos3 + 1);
		
		        // Trim whitespace (if necessary) and compare
		        if (fileName == name && fileEmail == email && filePassword == password) {
		            file.close();
		            return true; // Valid credentials
		        }
		    }
		
		    file.close();
		    return false; // No match found
		}
		void displayEventsFororganization(const string& orgname) {
			deleteList(head) ;
		  	loadEventsFromFile();
		   if (head == NULL) {
		        std::cout << "No events found." << std::endl;
		        return;
		    }
		
		    Event* current = head;
		    while (current != NULL) {
		    	current->loadQueuesFromFile();
		        // Only display events for the organizer with the matching name
		        if (current->getOrganizationname() == orgname) {
		            std::cout << "Event ID: " << current->getEventID() << std::endl;
		            std::cout << "Organization Name: " << current->getOrganizationname() << endl;
		            std::cout << "Event Name: " << current->geteventype() << endl;
		            std::cout << "Event Date: " << current->getEventdate() << endl;
		            std::cout << "Platinum Price: " << current->getplatinumprice() << endl;
		            std::cout << "Gold Price: " << current->getgoldprice() << endl;
		            std::cout << "Silver Price: " << current->getsilverprice() << endl;
		            current->displayTicketCounts();
		            std::cout << "--------------------------------" << endl;
		        }
		        current = current->getnext();
		    }
		        int eventIdChoice;
		        cout << "Press 1 to add tickets (1), or 0 to go back: ";
  				while (true) {
			        cin >> eventIdChoice;
			
			        // Check if input is Chracter
			        if (cin.fail()) {
			            cin.clear();
			            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore invalid input
			            std::cout << "Invalid input:Please enter an integer ";
			        } else {break;}
			    }
		        cin.ignore();
		
		    	 if (eventIdChoice == 1) {
		            int eventIdToAddTickets;
		            cout << "Enter the Event ID to add tickets: ";
		            cin >> eventIdToAddTickets;
		            cin.ignore();
		            addTicketsToEvent(eventIdToAddTickets, orgname);
		        }
		        else if(eventIdChoice==0){
		        	system("cls");
		        	EventlistMenu(orgname);
				}
				else{
					system("cls");
					EventlistMenu(orgname);
				}
	    }

		void addTicketsToEvent(int eventID, const std::string& orgname) {
		
		    Event* currentEvent = head;
		    while (currentEvent != NULL && currentEvent->getEventID() != eventID) {
		        currentEvent = currentEvent->getnext();
		    }
		
		    if (!currentEvent) {
		        	cout << "Event not found." << endl;
		        return;
		    }
		
		    if (currentEvent->getOrganizationname() != orgname) {
		        	cout << "You are not authorized to add tickets to this event." << endl;
		        return;
		    }
		
		    int numPlatinumToAdd, numGoldToAdd, numSilverToAdd;
		
		    cout << "Enter the number of Platinum tickets to add: ";
		    cin >> numPlatinumToAdd;
		    if (cin.fail()) { handleInvalidInput(); return; }
		    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		
		    cout << "Enter the number of Gold tickets to add: ";
		    cin >> numGoldToAdd;
		    if (cin.fail()) { handleInvalidInput(); return; }
		    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		
		    cout << "Enter the number of Silver tickets to add: ";
		    cin >> numSilverToAdd;
		    if (cin.fail()) { handleInvalidInput(); return; }
		    	cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		
		    currentEvent->addTickets(numPlatinumToAdd, numGoldToAdd, numSilverToAdd);
		 
 
}


		void loadEventsFromFile() {
		    ifstream file("Events.txt");
		    if (!file.is_open()) {
		        cout << "Unable to open Events.txt!" << endl;
		        return;
		    }
		
		    string line;
		    while (getline(file, line)) {
		        stringstream ss(line);
		        int id;
		        string orgname, eventname, eventDate, pltPrice, gldPrice, slvPrice;
		        
		        // Parse the line
		        char comma;
		        if (ss >> id >> comma && getline(ss, orgname, ',') && getline(ss, eventname, ',') &&
		            getline(ss, eventDate, ',') && getline(ss, pltPrice, ',') &&
		            getline(ss, gldPrice, ',') && getline(ss, slvPrice, ',')) {
		
		            // Create a new Event object and populate its details
		            Event* newEvent = new Event();
		            newEvent->seteventID(id);
		            newEvent->setnameOrganizer(orgname);
		            newEvent->seteventype(eventname);
		            newEvent->seteventdate(eventDate);
		            newEvent->setplatinumprice(pltPrice);
		            newEvent->setgoldprice(gldPrice);
		            newEvent->setsilverprice(slvPrice);
		
		            // Link the new Event to the list
		            if (head == NULL) {
		                head = newEvent;
		                tail = newEvent;
		            } else {
		                tail->setnext(newEvent);
		                newEvent->setprevious(tail);
		                tail = newEvent;
		            }
		        } else {
		            cerr << "Error parsing line: " << line << endl;
		        }
		    }
		    file.close();
		}

	    void displayEvents(string customerName, string customerEmail) {
	    	deleteList( head) ;
	    	loadEventsFromFile();
	        if (head == NULL) {
	            cout << "No events to display!" << endl;
	            cout<<"Press Enter to continue...."<<endl;
	            getch();
	            system("cls");
	            inside_Login(customerName, customerEmail);
	            return;
	        }
	
	        Event *temp = head;
	        while (temp != NULL) {
	        	temp->loadQueuesFromFile();
	            cout << "Event ID: " << temp->getEventID() << endl;
	            cout << "Organization Name: " << temp->getOrganizationname() << endl;
	            cout << "Event Name: " << temp->geteventype() << endl;
	            cout << "Event Date: " << temp->getEventdate() << endl;
	            cout << "Platinum Price: " << temp->getplatinumprice() << endl;
	            cout << "Gold Price: " << temp->getgoldprice() << endl;
	            cout << "Silver Price: " << temp->getsilverprice() << endl;
	            temp->displayTicketCounts();
	            cout << "--------------------------------" << endl;
	            temp = temp->getnext();
	        }
	           int eventIdToPurchase;
	    		cout << "Enter the Event ID to purchase a ticket: ";
  				while (true) {
			        cin >> eventIdToPurchase;
			
			        // Check if input is Chracter
			        if (cin.fail()) {
			            cin.clear();
			            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore invalid input
			            std::cout << "Invalid input. Please enter correct ID: ";
			        } else {break;}
			    }
				purchaseTicket(eventIdToPurchase,customerName,customerEmail);
	    }
		    // Add purchase functionality to EventList
		void purchaseTicket(int eventID,string customerName, string customerEmail) {
		    Event* currentEvent = head; // Start from head, no need to load file every time
		    while (currentEvent != NULL && currentEvent->getEventID()!= eventID) {
		        currentEvent = currentEvent->getnext();
		    }
		
		    if (currentEvent==NULL) {
		        cout << "Event not found for this id." << endl;
		        cout<<"Press Enter to continue..."<<endl;
		        getch();
		        system("cls");
		        inside_Login(customerName,customerEmail);
		    }
			else{
		    int ticketType;
		    cout << "Select ticket type:" << endl;
		    cout << "1. Platinum (Price: " << currentEvent->getplatinumprice() << ")" << endl;
		    cout << "2. Gold (Price: " << currentEvent->getgoldprice() << ")" << endl;
		    cout << "3. Silver (Price: " << currentEvent->getsilverprice() << ")" << endl;
		    cin >> ticketType;
		    cin.ignore(); // Clear newline
		
		    int numTicketsToBuy;
		    cout << "How many tickets do you want to buy? ";
		    while (true) {
		        cin >> numTicketsToBuy;
		        // Check if input is Chracter
		        if (cin.fail()) {
		            cin.clear();
		            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore invalid input
		            std::cout << "Invalid input.Please choose in integer "<<endl;
		        } else {break;}
			}
		    cin.ignore(); // Clear newline
		
		    int ticketsLeftBeforePurchase;
		    Ticketsqueue* selectedQueue = NULL; // Use a pointer to select the queue
		
		    if (ticketType == 1) {
		        selectedQueue = &currentEvent->platinumTickets;
		    } else if (ticketType == 2) {
		        selectedQueue = &currentEvent->goldTickets;
		    } else if (ticketType == 3) {
		        selectedQueue = &currentEvent->silverTickets;
		    } else {
		        cout << "Invalid ticket type." << endl;
		        return; // Important: Exit the function if the ticket type is invalid
		    }
		
		 if (selectedQueue) {
		            ticketsLeftBeforePurchase = selectedQueue->ticketsLeft();
		            if (numTicketsToBuy > ticketsLeftBeforePurchase) {
		                cout << "Not enough tickets available. Only " << ticketsLeftBeforePurchase << " left." << endl;
						getch();
						cout<<"Press Enter to continue"<<endl;
						system("cls");
						inside_Login(customerName,customerEmail);
		            } else {
		                for (int i = 0; i < numTicketsToBuy; i++) {
		                    selectedQueue->purchaseTicket();
		                }
		                cout<<"Tickets purchased successfully!" << endl;
		                cout<<"Tickets left : " << selectedQueue->ticketsLeft() << endl;
		                currentEvent->saveQueuesToFile(); // Save the updated queues, this is the most important change
		    			
		    			ofstream bookingFile("Booking.txt", ios::app);
			            if (bookingFile.is_open()) {
			                bookingFile << customerName << "," << customerEmail << "," << currentEvent->getEventID() << "," 
			                            << currentEvent->geteventype() << "," << ticketType << "," << numTicketsToBuy << endl;
			                bookingFile.close();
			            } else {
			                cout << "Unable to save booking!" << endl;
			            }

						cout<<"Press Enter to continue."<<endl;
		    			getch();
		    			system("cls");
		    			inside_Login(customerName,customerEmail);
		            }
			}
		}
	}

		void insertEvent(string orgname){
			string event_type, date, ticketplt_price, ticketgld_price, ticketslv_price;
            int eventID,nooftickets_plt, nooftickets_gld, nooftickets_slv;
			system("cls");
			cout<<"                                                      <<<<<<<<<>>>>>>>>>"<<endl;
			cout<<"                                                      | Insert   Event |"<<endl;
			cout<<"                                                      <<<<<<<<<>>>>>>>>>"<<endl<<endl; 
			cout<<"                                            =========>||"<<orgname<<"||<========="<<endl;
			cout<<"Enter the Unique ID of Event between " <<readEventID()<< " and "<<readEventIDplus1()<<" : ";
  			while (true) {
			        cin >> eventID;
			
			        // Check if input is Chracter
			        if (cin.fail()) {
			            cin.clear();
			            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore invalid input
			            std::cout << "Invalid input. Please enter an integer: ";
			        } else {break;}
			    }
				
			if(eventID>readEventIDplus1() || eventID < readEventID() ||  eventID == readEventID() || eventID==readEventIDplus1() ){
				if(eventID>=readEventIDplus1()){
					cout<<"You entered EventID greater than or equal to "<<readEventIDplus1()<<endl;
					cout<<"Press Enter to Re-Enter EventID. "<<endl;
					getch();
					system("Cls");
					insertEvent(orgname);
				}
				if(eventID<=readEventID()){
					cout<<"You entered EventID Less than or equal to "<<readEventID()<<endl;
					cout<<"Press Enter to Re-Enter EventID. "<<endl;
					getch();
					system("Cls");
					insertEvent(orgname);
				}

				
			}
			else{
			saveEventID(eventID);
			cin.ignore(); 
	 		cout << "Enter the name of Event : ";
            getline(cin, event_type);
            cout << "Enter the date of the Event :";
            getline(cin, date);
            cout << "Set prices of the Tickets : " << endl;
            cout << "For Platinum : RS "; cin >> ticketplt_price;
            cout << "For Gold     : RS "; cin >> ticketgld_price;
            cout << "For Silver   : RS "; cin >> ticketslv_price;
            cout << "No of Platinum Tickets you wanna launch :"; cin >> nooftickets_plt;
            cout << "No of   Gold   Tickets you wanna launch :"; cin >> nooftickets_gld;
            cout << "No of  Silver  Tickets you wanna launch :"; cin >> nooftickets_slv;

            // ***KEY CHANGE HERE***: Call insertEventList directly with the counts
            insertEventList(eventID,orgname, event_type, ticketplt_price, ticketgld_price, ticketslv_price, date, nooftickets_plt, nooftickets_gld, nooftickets_slv);

            system("cls");
            EventlistMenu(orgname);}
		}
		void deleteEvent(const string& orgname) {
			deleteList( head) ;
		    loadEventsFromFile();
		
		    if (head == NULL) {
		        cout << "No events found." << endl;
		        cout<<"Press Enter to continue..."<<endl;
		        getch();
		        system("cls");
		        EventlistMenu(orgname);
		    }
		
		    cout << "Your Events:\n"; // Display events before prompting for ID
		    bool eventsFound = false;
		    Event* currentForDisplay = head;
		    while (currentForDisplay != NULL) {
		        if (currentForDisplay->getOrganizationname() == orgname) {
		            cout << "Event ID: " << currentForDisplay->getEventID()
		                      << ", Event Name: " << currentForDisplay->geteventype()<<endl;
		            eventsFound = true;
		        }
		        currentForDisplay = currentForDisplay->getnext();
		    }
		
		    if (!eventsFound) {
		        cout << "You have no events to delete." <<endl;
		        cout<<"Press Enter to continue..."<<endl;
		        getch();
		        system("cls");
		        EventlistMenu(orgname);
		    }
		
		
		    int eventIDToDelete;
		    cout << "Enter the Event ID to delete: ";
  				while (true) {
			        cin >> eventIDToDelete;
			        // Check if input is Chracter
			        if (cin.fail()) {
			            cin.clear();
			            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore invalid input
			            std::cout << "Invalid input:Please enter correct ID ";
			        } else {break;}
			    }

		
		    Event* current = head;
		    Event* prev = NULL;
		
		    while (current != NULL && current->getEventID() != eventIDToDelete) {
		        prev = current;
		        current = current->getnext();
		    }
		
		    if (!current) {
		        cout << "Event not found." << endl;
		        return;
		    }
		
		    if (current->getOrganizationname() != orgname) {
		        cout << "You are not authorized to delete this event." <<endl;
		        cout<<"Press Enter to continue..."<<endl;
		        getch();
		        system("cls");
		        EventlistMenu(orgname);
		    }
		
		    if (prev) {
		        prev->setnext(current->getnext());
		    } else {
		        head = current->getnext();
		    }
		
		    if (current == tail) {
		        tail = prev;
		    }
		    removeQueuesFromFile(eventIDToDelete);
		    delete current;
		
		    ofstream outFile("Events.txt");
		    if (outFile.is_open()) {
		        Event* temp = head;
		        while (temp != NULL) {
		            outFile << temp->getEventID() << "," << temp->getOrganizationname() << "," << temp->geteventype() << "," << temp->getEventdate() << ","
		                << temp->getplatinumprice() << "," << temp->getgoldprice() << "," << temp->getsilverprice() <<endl;
		            temp = temp->getnext();
		        }
		        outFile.close();
		    } else {
		        cerr << "Error opening Events.txt for writing!" <<endl;
		    }
		    cout << "Event deleted successfully." <<endl<<endl;
		    cout<<"Press Enter to continue."<<endl;
		    getch();
		    system("cls");
		    EventlistMenu(orgname);
		    //deleteList( head) ;
		}
		
	    void updateEvent(const string& orgname) {
	    	deleteList( head) ;
		    loadEventsFromFile();
		
		    if (head == NULL) {
		    	cout << "No events found." << endl;
		        cout<<"Press Enter to continue..."<<endl;
		        getch();
		        system("cls");
		        EventlistMenu(orgname);
		    }
		
		    cout << "Your Events:\n";
		    bool eventsFound = false;
		    Event* currentForDisplay = head;
		    while (currentForDisplay != NULL) {
		        if (currentForDisplay->getOrganizationname() == orgname) {
		            cout << "Event ID: " << currentForDisplay->getEventID()
		                      << ", Event Name: " << currentForDisplay->geteventype() << endl;
		            eventsFound = true;
		        }
		        currentForDisplay = currentForDisplay->getnext();
		    }
		
		    if (!eventsFound) {
		        cout << "You have no events to update." <<endl;
		        cout<<"Press Enter to continue..."<<endl;
		        getch();
		        system("cls");
		        EventlistMenu(orgname);
		    }
		
		    int eventIDToUpdate;
		    cout << "Enter the Event ID to update: ";
		    //cin >> eventIDToUpdate;
		    while (true) {
		        cin >> eventIDToUpdate;
		
			        // Check if input is Chracter
			       if (cin.fail()) {
		            cin.clear();
		            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore invalid input
		            std::cout << "Invalid input:Please enter an integer ";
			        } else {break;}
			    }

			cin.ignore();
		    Event* current = head; // Correct pointer to find the event to update
		    bool eventFoundAndOwned = false;
		    while (current != NULL) {
		        if (current->getEventID() == eventIDToUpdate && current->getOrganizationname() == orgname) {
		            eventFoundAndOwned = true;
		            break;
		        }
		        current = current->getnext();
		    }
		
		    if (!eventFoundAndOwned) {
		        std::cout << "Event not found or you are not authorized to update it." << std::endl;
		        cout<<"Press Enter to continue..."<<endl;
		        getch();
		        system("cls");
		        EventlistMenu(orgname);
		       
		    }
		
		    // Display event details BEFORE updating
		    current->loadQueuesFromFile();
		    cout<<"\nUpdating Event:\n";
		    cout<<"Event ID: " << current->getEventID() << endl;
		    cout<<"Event Name: " << current->geteventype() << endl;
		    cout<<"Event Date: "<<current->getEventdate()<<endl;
		    cout<<"Platinum Price: " << current->getplatinumprice() << endl;
		    cout<<"Gold Price: " << current->getgoldprice() << endl;
		    cout<<"Silver Price: " << current->getsilverprice() << endl;
		    current->displayTicketCounts();
		
		    string newEventType, newDate, newPlatinumPrice, newGoldPrice, newSilverPrice;
		    cout<<"\nEnter new Event Name(Type)) (or press Enter to keep current): "; getline(cin, newEventType);
		    cout<<"Enter new Date (or press Enter to keep current): "; getline(cin, newDate);
		    cout<<"Enter new Platinum Price (or press Enter to keep current): "; getline(cin, newPlatinumPrice);
		    cout<<"Enter new Gold Price (or press Enter to keep current): "; getline(cin, newGoldPrice);
		    cout<<"Enter new Silver Price (or press Enter to keep current): "; getline(cin, newSilverPrice);
		
		    if (!newEventType.empty()) current->seteventype(newEventType);
		    if (!newDate.empty()) current->seteventdate(newDate);
		    if (!newPlatinumPrice.empty()) current->setplatinumprice(newPlatinumPrice);
		    if (!newGoldPrice.empty()) current->setgoldprice(newGoldPrice);
		    if (!newSilverPrice.empty()) current->setsilverprice(newSilverPrice);
		
		    ofstream outFile("Events.txt");
		    if (outFile.is_open()) {
		        Event* temp = head;
		        while (temp != NULL) {
		            outFile << temp->getEventID() << "," << temp->getOrganizationname() << "," << temp->geteventype() << "," << temp->getEventdate() << ","
		                << temp->getplatinumprice() << "," << temp->getgoldprice() << "," << temp->getsilverprice() << endl;
		            temp = temp->getnext();
		        }
		        outFile.close();
		        current->saveQueuesToFile();
		    } else {
		        cerr << "Error opening Events.txt for writing!" <<endl;
		    }
		
		    cout<<"Event updated successfully."<<endl<<endl;
		    cout<<"Press Enter to continue."<<endl;
		    getch();
		    system("cls");
		    EventlistMenu(orgname);
		}
};
void centerText(const std::string& text, int lineOffset = 0) {
		    CONSOLE_SCREEN_BUFFER_INFO csbi;
		    GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi);
		    int consoleWidth = csbi.dwSize.X;
		    int consoleHeight = csbi.dwSize.Y;
		    int xPos = (consoleWidth - text.length()) / 2;
		    int yPos = (consoleHeight / 2) + lineOffset;  
		    COORD coord = { xPos, yPos };
		    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
		    cout << text << endl;
		}
void MainMenu(){
		    string message3 = "<<<<<<<<<<<>>>>>>>>>>";
		    string message4 = "|     BookWithMe    |";
		    string message5 = "<<<<<<<<<<<>>>>>>>>>>";
		    centerText(message3);
		    centerText(message4, 1); 
		    centerText(message5, 2);
		    cout<<endl<<endl;
		    string message6="                                                 <<<<<<<<<<>>>>>>>>>>";
		    string message7="                                                 |Press L for Login |";
		    string message8="                                                 <<<<<<<<<<>>>>>>>>>>";
		    cout<<message6<<endl;
		    cout<<message7<<endl; 
		    cout<<message8;
		    cout<<endl;
		    string message16="                                                 <<<<<<<<<<>>>>>>>>>>";
		    string message17="                                                 |Press S for SignUP|";
		    string message18="                                                 <<<<<<<<<<>>>>>>>>>>";
		    cout<<message16<<endl;
		    cout<<message17<<endl; 
		    cout<<message18<<endl;
		    string message0="                                                 <<<<<<<<<<>>>>>>>>>>";
		    string message1="                                                 |Press  E  to  Exit|";
		    string message2="                                                 <<<<<<<<<<>>>>>>>>>>";
		    cout<<message0<<endl;
		    cout<<message1<<endl; 
		    cout<<message2<<endl;
		    string a;
		    cin>>a;
		    system("cls");
		    if(a=="l"||a=="L"){
		    	Login();
			}
			else if(a=="s"||a=="S"){
				SignUP();
			}
			else if(a=="e"||a=="E"){
				return;
			}
			else{
			system("cls");
			MainMenu();
			}
	}
void Book(){
	cout<<" _______________           _________________         _________________      ||           //"<<endl;
    cout<<"||               \\\\       /                 \\       /                 \\     ||          //"<<endl;
    cout<<"||  __________    \\\\     /                   \\     /                   \\    ||         //"<<endl;
    cout<<"|| |          |    |    |    _____________    |   |    _____________    |   ||        //"<<endl;
    cout<<"|| |          |    |    |   /             \\   |   |   /             \\   |   ||       //"<<endl;
    cout<<"|| |__________|   //    |  |   __     __   |  |   |  |   __     __   |  |   ||      //"<<endl;
    cout<<"||_______________//     |  |               |  |   |  |               |  |   ||_____//   "<<endl;
    cout<<"||             \\\\       |  |               |  |   |  |               |  |   ||-----\\\\   "<<endl;
    cout<<"|| ___________  \\\\      |  |               |  |   |  |               |  |   ||      \\\\ "<<endl;
    cout<<"|||           \\  \\\\     |  |  \\_________/  |  |   |  |  \\_________/  |  |   ||       \\\\ "<<endl;
    cout<<"|||           ||  \\\\    |  |      \\__/     |  |   |  |      \\__/     |  |   ||        \\\\"<<endl;
    cout<<"|||           ||   |    |  |               |  |   |  |               |  |   ||         \\\\"<<endl;
    cout<<"|||           ||   |    |  |               |  |   |  |               |  |   ||          \\\\"<<endl;
    cout<<"|||           ||   |    |  |               |  |   |  |               |  |   ||           \\\\"<<endl;
    cout<<"|||___________/    |    |   \\_____________/   |   |   \\_____________/   |   ||            \\\\"<<endl;
    cout<<"||                //     \\                   /    \\                    /    ||             \\\\"<<endl;
	cout<<"||_______________//       \\_________________/      \\__________________/     ||              \\\\"<<endl;
	cout<<endl;
}
void With(){
	cout<<"                   ||             //\\\\             ||  ___________________  ___________________  ||                 ||"<<endl;
    cout<<"                   ||            //  \\\\            ||          ||                   ||           ||                 ||"<<endl;
    cout<<"                   ||           //    \\\\           ||          ||                   ||           ||                 ||"<<endl;
    cout<<"                   ||          //      \\\\          ||          ||                   ||           ||                 ||"<<endl;
    cout<<"                   ||         //        \\\\         ||          ||                   ||           ||                 ||"<<endl;
    cout<<"                   ||        //          \\\\        ||          ||                   ||           ||                 ||" <<endl;
    cout<<"                   ||       //            \\\\       ||          ||                   ||           ||_________________||"<<endl;
    cout<<"                   ||      //              \\\\      ||          ||                   ||           ||                 ||"<<endl;
    cout<<"                   ||     //                \\\\     ||          ||                   ||           ||                 ||"<<endl;
    cout<<"                   ||    //                  \\\\    ||          ||                   ||           ||                 || "<<endl;
    cout<<"                   ||   //                    \\\\   ||          ||                   ||           ||                 ||"<<endl;
    cout<<"                   ||  //                      \\\\  ||          ||                   ||           ||                 ||"<<endl;
    cout<<"                   || //                        \\\\ ||          ||                   ||           ||                 ||"<<endl;
    cout<<"                   ||//                          \\\\||  ________||_________          ||           ||                 ||"<<endl;
	cout<<endl;
}
void Me(){
	cout<<"                                    ||\\\\                          //||  ______________________"<<endl;
    cout<<"                                    || \\\\                        // ||  ||                    "<<endl;
    cout<<"                                    ||  \\\\                      //  ||  ||                    "<<endl;
    cout<<"                                    ||   \\\\                    //   ||  ||                    "<<endl;
    cout<<"                                    ||    \\\\                  //    ||  ||                    "<<endl;
    cout<<"                                    ||     \\\\                //     ||  ||                    "<<endl;
    cout<<"                                    ||      \\\\              //      ||  ||                    "<<endl;
    cout<<"                                    ||       \\\\            //       ||  ||____________________"<<endl;
    cout<<"                                    ||        \\\\          //        ||  ||                    "<<endl;
    cout<<"                                    ||         \\\\        //         ||  ||                    "<<endl;
    cout<<"                                    ||          \\\\      //          ||  ||                    "<<endl;
    cout<<"                                    ||           \\\\    //           ||  ||                    "<<endl;
    cout<<"                                    ||            \\\\  //            ||  ||                    "<<endl;
    cout<<"                                    ||             \\\\//             ||  ||____________________"<<endl;
	cout<<endl;
}
bool checkIfEmailExistsCustomer(const string& email) {
    ifstream file("customers.txt");
    string line;
    
    while (getline(file, line)) {
        size_t pos1 = line.find(",");
        size_t pos2 = line.find(",", pos1 + 1);
		size_t pos3 = line.find(",", pos2 + 1);
		string fileEmail = line.substr(pos2 + 1, pos3 - pos2 - 1); 
       // string fileEmail = line.substr(pos1 + 1, pos2 - pos1 - 1);
        
        if (fileEmail == email) {
            return true;  // Email exists
        }
    }
    return false;  // Email doesn't exist
}
bool checkIfEmailExistsEventOrganizer(const string& email) {
    ifstream file("EventsOrganizer.txt");
    string line;
    
    while (getline(file, line)) {
        size_t pos1 = line.find(",");
        size_t pos2 = line.find(",", pos1 + 1);
		size_t pos3 = line.find(",", pos2 + 1);
		string fileEmail = line.substr(pos2 + 1, pos3 - pos2 - 1); 
        
        if (fileEmail == email) {
            return true;  // Email exists
        }
    }
    return false;  // Email doesn't exist
}
void SignUP() {
    cout << "							<<<<<<<<>>>>>>>" << endl;
    cout << "							|   SIGN UP   |" << endl;
    cout << "							<<<<<<<<>>>>>>>" << endl;
    cout << "Do you wanna signUP as a:" << endl;
    cout << "   <<<<<<<<<>>>>>>>>" << endl;
    cout << "1->| USER/CUSTOMER |" << endl;
    cout << "   <<<<<<<<<>>>>>>>>" << endl;
    cout << "   <<<<<<<<<>>>>>>>>" << endl;
    cout << "2->|Event Organizer|" << endl;
    cout << "   <<<<<<<<<>>>>>>>>" << endl;
    cout << "   <<<<<<<<<>>>>>>>>" << endl;
    cout << "3->|      EXIT     |" << endl;
    cout << "   <<<<<<<<<>>>>>>>>" << endl;
    int choice;
      			while (true) {
			        cin >> choice;
			
			        // Check if input is Chracter
			        if (cin.fail()) {
			            cin.clear();
			            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore invalid input
			            std::cout << "please enter correct choice  ";
			        } else {break;}
			    }
				
    cin.ignore();
    system("cls");
    if (choice== 1) {
        cout << "                             <<<<<<<<<<>>>>>>>" << endl;
        cout << "                         >>>>>>|USER/CUSTOMER|<<<<<<<<<" << endl;
        cout << "                             <<<<<<<<<<>>>>>>>" << endl;
        string name;
        string phonenumber;
        string Email;
        string Password;
        cout << "Enter  your  name   : ";
        getline(cin, name);
        cout << "Enter your Phone No : ";
        getline(cin,phonenumber);
        cout << "Enter your Email ID : ";
        getline(cin,Email);
        
                // Check if email already exists
        if (checkIfEmailExistsCustomer(Email)) {
            cout << "You have already signed up. Please log in instead." << endl;
            cout<<"Press any key to Login "<<endl;
            Sleep(1000);
            getch();
            system("cls");
            Login();
        }
        
        cout << "Enter your Password : ";
        getline(cin,Password);

        cout<<"SignUP Successful"<<endl;
        Sleep(1000);
        CustomerList newlist;
        newlist.insertCustomer(name, phonenumber, Email, Password);
        system("cls");
        inside_Login(name,Email);
       // newlist.displaycustomers();
    }
    else if(choice==2){	    		
	        cout << "                             <<<<<<<<<<<>>>>>>>>" << endl;
	        cout << "                         >>>>>>|Event Organizer|<<<<<<<<<" << endl;
	        cout << "                             <<<<<<<<<<<>>>>>>>>" << endl;
	        string name;
	        string phonenumber;
	        string Email;
	        string Password;
	        cout << "Enter  your  name   : ";
	        getline(cin, name);
	        cout << "Enter your Phone No : ";
	        getline(cin,phonenumber);
	        cout << "Enter your Email ID : ";
	        getline(cin,Email);
	        
	                // Check if email already exists
        if (checkIfEmailExistsEventOrganizer(Email)) {
            cout << "You have already signed up. Please log in instead." << endl;
            cout<<"press any Chracter to continue"<<endl;
            getch();
            system("cls");
            Login();
        }
        
	        
	        cout << "Enter your Password : ";
	        getline(cin,Password);
	
	        cout<<"SignUP Successful"<<endl;
	        Sleep(1000);
	        EventList neweventlist;
	        neweventlist.insert_EventOrganizer_detail(name, phonenumber, Email, Password);
	        //neweventlist.displaycustomers();	
			}
		else if(choice==3){
			system("cls");
			MainMenu();
		}
		else{
			system("cls");
			SignUP();
		}
    }
void inside_Login(string customerName, string customerEmail) {
	    cout<<"Choose your choice : "<<endl;
		cout<<"   <<<<<<<<<<>>>>>>>>                 <<<<<<<<<<>>>>>>>>                               <<<<<<<<<<>>>>>>>>"<<endl;
		cout<<"1->|     Events     |              2->|    BooKings    |                            3->|       Exit     |"<<endl;
		cout<<"   <<<<<<<<<<>>>>>>>>                 <<<<<<<<<<>>>>>>>>                               <<<<<<<<<<>>>>>>>>"<<endl;
	
	    int choice;
	    	while (true) {
			        cin >> choice;
			
			        // Check if input is Chracter
			        if (cin.fail()) {
			            cin.clear();
			            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore invalid input
			            std::cout << "please enter correct choice  ";
			        } else {break;}
			    }
				
	    if (choice == 1) {
			system("cls");
	    	cout << "                             <<<<<<<<<<<>>>>>>>>" << endl;
	    	cout << "                         >>>>>>|    Events     |<<<<<<<<<" << endl;
	    	cout << "                             <<<<<<<<<<<>>>>>>>>" << endl;
	        EventList events;
	        events.displayEvents(customerName, customerEmail); // Pass customer details
	    } else if (choice == 2) {
			system("cls");
	    	cout << "                             <<<<<<<<<<<>>>>>>>>" << endl;
	    	cout << "                         >>>>>>| Your Bookings |<<<<<<<<<" << endl;
	    	cout << "                             <<<<<<<<<<<>>>>>>>>" << endl;
	        CustomerList customerList;
	        customerList.displayBookings(customerName,customerEmail);
	    } else if (choice == 3) {
	        system("cls");
	        MainMenu();
	    }
	}

void Login() {
	cout << "							   <<<<<<<<>>>>>>>" << endl;
    cout << "							   |    LOGIN    |" << endl;
    cout << "							   <<<<<<<<>>>>>>>" << endl;
    cout << "Do you wanna LogiIN as a:" << endl;
    cout << "   <<<<<<<<<>>>>>>>>" << endl;
    cout << "1->| USER/CUSTOMER |" << endl;
    cout << "   <<<<<<<<<>>>>>>>>" << endl;
    cout << "   <<<<<<<<<>>>>>>>>" << endl;
    cout << "2->|Event Organizer|" << endl;
    cout << "   <<<<<<<<<>>>>>>>>" << endl;
    cout << "   <<<<<<<<<>>>>>>>>" << endl;
    cout << "3->|      EXIT     |" << endl;
    cout << "   <<<<<<<<<>>>>>>>>" << endl;
    int choice;
   	while (true) {
			        cin >> choice;
			
			        // Check if input is Chracter
			        if (cin.fail()) {
			            cin.clear();
			            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore invalid input
			            std::cout << "please enter correct choice  ";
			        } else {break;}
			    }
				
    cin.ignore();
    system("cls");
    if (choice == 1) {
        cout << "                             <<<<<<<<<<>>>>>>>" << endl;
        cout << "                         >>>>>>|USER/CUSTOMER|<<<<<<<<<" << endl;
        cout << "                             <<<<<<<<<<>>>>>>>" << endl;
    
    	string email, password,name;
	    cout << "Enter your email: ";
	    getline(cin,email);
	    cout << "Enter your password: ";
	    getline(cin,password);
	
	    CustomerList customerList;
	    if (customerList.verifyLogin(email, password,name)) {
	        cout << "Login successful!" << endl;
	        Sleep(1000);
	        system("cls");
			inside_Login(name,email);
	
	
	     } else {
	      	    cout << "Invalid email or password or name.You need to |SignUp| or |LOGIN| again" << endl<<endl;;
	      	    cout<<"press 1 to Login Again 2 to signUp and any key to go back"<<endl;
	      	    int choice;
	      	    cin>>choice;
	      	    if(choice==1){
			    system("cls");
			    Login();}
			    else if(choice==2){
			    	system("cls");
			    	SignUP();
				}
				else {
					system("cls");
					MainMenu();
				}
	     }
	}
	else if(choice==2){	    		
		    cout << "                                               <<<<<<<<<<<>>>>>>>>" << endl;
	    	cout << "                                          >>>>>>|Event Organizer|<<<<<<<<<" << endl;
	   		cout << "                                               <<<<<<<<<<<>>>>>>>>" << endl;
    
			string email, password,name;
	    	cout<<"Enter you name : ";
	    	getline(cin,name);
	    	//cout<<"Press any key to continue "<<endl;
	    	//getch();
	    	cout << "Enter your email: ";
	    	getline(cin,email);
	    	cout << "Enter your password: ";
	    	getline(cin,password);
	
	        EventList newlist;
			if (newlist.verifyLoginEvent(name, email, password)) {
			    cout << "Login successful!" << endl;
			    Sleep(300);
			    system("cls");
			    newlist.EventlistMenu(name);
			} else {
	      	    cout << "Invalid email or password or name.You need to |SignUp| or |LOGIN| again" << endl<<endl;;
	      	    cout<<"press 1 to Login Again 2 to signUp and any key to go back"<<endl;
	      	    int choice;
	      	    cin>>choice;
	      	    if (cin.fail()) {
	        		cout << "Invalid input. Please enter 1 OR 2." << endl;
	   		    	cin.clear(); // Clear error flags
	        		cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard bad input
	       			 return; // or call login() again for retry
	            }
	      	    if(choice==1){
			    system("cls");
			    Login();}
			    else if(choice==2){
			    	system("cls");
			    	SignUP();
				}
				else{
					MainMenu();
				}
				
			}
		}
		else if(choice==3){
			system("cls");
			MainMenu();
		}
		else{
			system("cls");
			Login();
		}
	}
int main() {
    system("color 70");
    	Book();
	Sleep(700);
	system("cls");
	With();
	Sleep(700);
	system("cls");
	Me();
	Sleep(700);
	system("cls");
    string message0 = "<<<<<<<<<<<>>>>>>>>>>";
    string message1 = "|       Welcome     |";
    string message2 = "<<<<<<<<<<<>>>>>>>>>>";
    centerText(message0);
    centerText(message1, 1); 
    centerText(message2, 2);  
    Sleep(1000); 
    system("cls");
    MainMenu();
    return 0;
}
	



